﻿using System.Collections.Generic;

namespace _002_ConstructorInjection
{
    public interface IDataAccessObject
    {
        List<string> GetFiles();
    }
}
