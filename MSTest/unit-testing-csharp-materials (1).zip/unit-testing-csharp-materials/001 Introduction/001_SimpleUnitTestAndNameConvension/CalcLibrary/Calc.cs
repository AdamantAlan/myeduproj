﻿namespace CalcLibrary
{
    // Класс, которй необходимо тестировать
    public class Calc
    {
        public static double Sum(double x, double y)
        {
            return x + y;
        }
    }
}
