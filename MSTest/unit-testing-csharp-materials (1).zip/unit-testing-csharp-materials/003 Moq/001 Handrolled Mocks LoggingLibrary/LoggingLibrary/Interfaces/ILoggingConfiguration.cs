﻿namespace LoggingLibrary
{
    public interface ILoggingConfiguration
    {
        bool LogStackFor(LogLevel level);
    }
}