﻿namespace LoggingLibrary
{
    public interface IMessageBodyGenerator
    {
        void CreateBody(string message);
    }
}